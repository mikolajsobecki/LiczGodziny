'use client';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { FirebaseClientProvider } from '@/firebase/client-provider';
import Script from 'next/script';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pl">
      <head>
        <title>LiczGodziny</title>
        <meta name="description" content="Track your work hours and earnings" />

        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#8c9fb9" />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />

        <link
          href="https://fonts.googleapis.com/css2?family=Inter&display=swap"
          rel="stylesheet"
        />

        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="LiczGodziny" />
        <link rel="apple-touch-icon" href="/icons/icon-180x180.png" />
      </head>

      <body className="font-body antialiased">
        <FirebaseClientProvider>
          {children}
          <Toaster />
        </FirebaseClientProvider>

        {/* Rejestracja Service Workera */}
        <Script id="service-worker-registration" strategy="afterInteractive">
          {`
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                  .then(registration => {
                    console.log('SW registered:', registration.scope);
                  })
                  .catch(err => {
                    console.log('SW registration failed:', err);
                  });
              });
            }
          `}
        </Script>

        {/* Prośba o zgodę na powiadomienia */}
        <Script id="notification-permission" strategy="afterInteractive">
          {`
            if ('Notification' in window) {
              Notification.requestPermission().then(permission => {
                console.log('Notification permission:', permission);
              });
            }
          `}
        </Script>

      </body>
    </html>
  );
}
