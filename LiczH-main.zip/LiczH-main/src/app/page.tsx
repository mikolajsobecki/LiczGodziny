'use client';

import { useEffect, useState } from 'react';
import { useAuth, useUser, initiateAnonymousSignIn, useFirestore, useDoc, useMemoFirebase, setDocumentNonBlocking } from '@/firebase';
import { TimeEntryForm } from '@/components/TimeEntryForm';
import { SummaryDashboard } from '@/components/SummaryDashboard';
import { Button } from '@/components/ui/button';
import { Settings, Loader2 } from 'lucide-react';
import { doc } from 'firebase/firestore';
import type { UserProfile } from '@/lib/types';
import { UserSettingsDialog } from '@/components/UserSettingsDialog';
import { useNotificationReminder } from '@/hooks/use-notification-reminder';

export default function HomePage() {
  const auth = useAuth();
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const userDocRef = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return doc(firestore, 'users', user.uid);
  }, [firestore, user]);

  const { data: userProfile, isLoading: isProfileLoading } = useDoc<UserProfile>(userDocRef);

  // Hook do obsługi powiadomień
  useNotificationReminder(user && userProfile ? {...userProfile, id: user.uid} : null);

  useEffect(() => {
    if (auth && !user && !isUserLoading) {
      initiateAnonymousSignIn(auth);
    }
  }, [user, isUserLoading, auth]);

  useEffect(() => {
    if (firestore && user && !isProfileLoading && !userProfile) {
      // User is loaded, profile has been checked, and it doesn't exist. Create it.
      const newUserProfile: UserProfile = {
        name: user.displayName,
        email: user.email,
        regularRate: 30, // Default regular rate (podwyższona na start)
        overtimeRate: 43, // Default overtime rate (podwyższona na start)
      };
      const userDoc = doc(firestore, 'users', user.uid);
      setDocumentNonBlocking(userDoc, newUserProfile, { merge: true });
    }
  }, [user, userProfile, isProfileLoading, firestore]);

  // Render the layout immediately.
  // The child components will handle their own loading states internally.
  return (
    <>
      <div className="min-h-screen">
        <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <h1 className="text-2xl font-bold tracking-tight">LiczGodziny</h1>
              {user && (
                <Button variant="outline" size="icon" onClick={() => setIsSettingsOpen(true)} disabled={isProfileLoading || !userProfile}>
                  {isProfileLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Settings className="h-5 w-5" />}
                  <span className="sr-only">Ustawienia</span>
                </Button>
              )}
            </div>
          </div>
        </header>
        <main className="container mx-auto p-4 sm:p-6 lg:p-8">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="lg:col-span-1">
              {/* The user object might not be ready, so we handle loading state or pass uid conditionally */}
              <TimeEntryForm userId={user?.uid ?? null} />
            </div>
            <div className="lg:col-span-2">
              <SummaryDashboard userId={user?.uid ?? null} />
            </div>
          </div>
        </main>
      </div>
      {user && userProfile && (
        <UserSettingsDialog
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          userProfile={{...userProfile, id: user.uid}}
        />
      )}
    </>
  );
}
