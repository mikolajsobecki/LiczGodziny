import { useEffect } from 'react';
import type { UserProfile } from '@/lib/types';

/**
 * Hook do obsługi powiadomień przypomnień o dodaniu godzin
 */
export function useNotificationReminder(userProfile: UserProfile & { id: string } | null) {
  useEffect(() => {
    if (!userProfile || !userProfile.reminderEnabled || !userProfile.reminderTime) {
      return;
    }

    // Żądamy permisji na powiadomienia
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    // Sprawdzamy godzinę co minutę
    const interval = setInterval(() => {
      const now = new Date();
      const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

      if (currentTime === userProfile.reminderTime) {
        // Wysłanie powiadomienia
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification('Przypomnienie LiczH', {
            body: 'Nie zapomnij o wpisaniu dzisiejszych godzin pracy! ⏰',
            icon: '/manifest.json',
            tag: 'work-reminder', // Unika duplikacji powiadomień
          });
        }

        // Czekamy minutę żeby nie wysłać powiadomienia wiele razy
        setTimeout(() => {
          // Powiadomienie już wysłane
        }, 60000);
      }
    }, 60000); // Sprawdzaj co minutę

    return () => clearInterval(interval);
  }, [userProfile]);
}
