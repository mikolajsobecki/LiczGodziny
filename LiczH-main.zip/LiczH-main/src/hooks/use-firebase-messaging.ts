import { useEffect } from 'react';
import { initializeFirebase } from '@/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import type { Firestore } from 'firebase/firestore';
import type { Messaging } from 'firebase/messaging';

/**
 * Hook which obtains a FCM token (prompting the user if necessary) and
 * persists it to the user's profile document.  The token is only requested
 * when reminders are enabled; clearing the token when the feature is disabled
 * helps keep the database clean.
 *
 * The token can later be used from a Cloud Function (not included here) to
 * schedule a push notification at the desired time even if the PWA isn't
 * currently open.  If the user revokes permission or uninstall the PWA, the
 * FCM SDK will automatically invalidate the token and should be refreshed.
 */
export function useFirebaseMessaging(
  userId: string | null,
  reminderEnabled: boolean | undefined
) {
  const { toast } = useToast();

  useEffect(() => {
    if (!userId) return;

    const { firestore, messaging } = initializeFirebase();
    if (!firestore) return;
    if (!messaging) {
      return;
    }

    const userDocRef = doc(firestore, 'users', userId);

    const saveToken = async (token: string | null) => {
      try {
        await updateDoc(userDocRef, { fcmToken: token });
        console.log('FCM token saved for user', userId, token);
        toast({
          title: token ? 'Token zapisany' : 'Token usunięty',
          description: token ? 'Powiadomienia push będą działać.' : 'Przypomnienia push wyłączone.',
        });
      } catch (e) {
        console.warn('Unable to update FCM token', e);
        toast({
          variant: 'destructive',
          title: 'Błąd',
          description: 'Nie udało się zapisać tokenu powiadomień.',
        });
      }
    };

    if (!reminderEnabled) {
      saveToken(null);
      return;
    }

    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then((perm) => {
        if (perm !== 'granted') {
          toast({
            variant: 'destructive',
            title: 'Uprawnienia odrzucone',
            description: 'Nie dostaniesz powiadomień push bez zgody.',
          });
        }
      });
    }

    if ('Notification' in window && Notification.permission === 'granted') {
      import('firebase/messaging').then(({ getToken, onMessage }) => {
        const vapidKey = process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY || '';

        getToken(messaging, { vapidKey })
          .then((currentToken) => {
            if (currentToken) {
              saveToken(currentToken);
            } else {
              console.warn('FCM returned no token');
            }
          })
          .catch((err) => {
            console.warn('Error retrieving FCM token', err);
            toast({
              variant: 'destructive',
              title: 'Błąd pobierania tokenu',
              description: String(err),
            });
          });

        const unsubscribe = onMessage(messaging, (payload) => {
          console.log('FCM foreground message received', payload);
          // optionally notify user via toast
        });

        return () => unsubscribe();
      });
    }
  }, [userId, reminderEnabled, toast]);
}
