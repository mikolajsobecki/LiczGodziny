export const firebaseConfig = {
  "projectId": "studio-1591233154-18b9e",
  "appId": "1:643520958116:web:4305737f4094462ac16031",
  "apiKey": "AIzaSyBeiApQl381cFLIfsEH1gPHJW5umpt9Od0",
  "authDomain": "studio-1591233154-18b9e.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "643520958116"
};
