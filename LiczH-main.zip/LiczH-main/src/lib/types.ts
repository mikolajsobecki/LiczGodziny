export type UserProfile = {
  email?: string | null;
  name?: string | null;
  regularRate: number;
  overtimeRate: number;
  reminderTime?: string | null; // HH:MM format, e.g., "18:30"
  reminderEnabled?: boolean;
};

export type WorkDay = {
  id: string;
  userId: string;
  date: string; // ISO string
  hoursWorked: number;
  hourlyRate: number;
  earnings: number;
  overtimeHours?: number; // Optional to not break existing entries
};
