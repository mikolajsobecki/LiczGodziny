'use client';

import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import { format } from 'date-fns';
import { Clock, TrendingUp, Timer } from 'lucide-react';
import type { WorkDay } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { WorkHistoryTable } from './WorkHistoryTable';
import { Skeleton } from './ui/skeleton';

interface SummaryDashboardProps {
  userId: string | null;
}

const chartConfig = {
  hours: {
    label: "Godziny",
    color: "hsl(var(--primary))",
  },
} satisfies ChartConfig;

export function SummaryDashboard({ userId }: SummaryDashboardProps) {
  const firestore = useFirestore();
  
  const workDaysQuery = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return query(collection(firestore, 'users', userId, 'workDays'), orderBy('date', 'asc'));
  }, [firestore, userId]);

  const { data: entries, isLoading } = useCollection<WorkDay>(workDaysQuery);

  const { totalHours, totalEarnings, totalOvertimeHours } = (entries || []).reduce(
    (acc, entry) => {
      acc.totalHours += entry.hoursWorked;
      acc.totalEarnings += entry.earnings;
      acc.totalOvertimeHours += entry.overtimeHours || 0;
      return acc;
    },
    { totalHours: 0, totalEarnings: 0, totalOvertimeHours: 0 }
  );

  const chartData = (entries || []).map(entry => ({
    date: format(new Date(entry.date), 'MMM d'),
    hours: entry.hoursWorked,
  }));
  
  if (isLoading && !entries) {
    return (
        <div className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
                <Skeleton className="h-[120px] w-full" />
                <Skeleton className="h-[120px] w-full" />
                <Skeleton className="h-[120px] w-full" />
            </div>
            <Skeleton className="h-[350px] w-full" />
            <Skeleton className="h-[400px] w-full" />
        </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Całkowita liczba godzin</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalHours.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">ze wszystkich wpisów</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Nadgodziny</CardTitle>
            <Timer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalOvertimeHours.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">ze wszystkich wpisów</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Całkowite zarobki</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 text-muted-foreground"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 18V6" />
              <path d="M16 14H8" />
              <path d="M16 10H8" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalEarnings.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} zł</div>
            <p className="text-xs text-muted-foreground">Na podstawie zarejestrowanych godzin</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Historia pracy</CardTitle>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <ChartContainer config={chartConfig} className="h-[250px] w-full">
              <BarChart accessibilityLayer data={chartData} margin={{ top: 20, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                <Tooltip
                  cursor={false}
                  content={<ChartTooltipContent indicator="dot" />}
                />
                <Bar dataKey="hours" fill="var(--color-hours)" radius={4} />
              </BarChart>
            </ChartContainer>
          ) : (
            <div className="flex flex-col items-center justify-center h-[250px] text-center rounded-lg border-2 border-dashed border-muted">
              <TrendingUp className="h-12 w-12 text-muted-foreground" />
              <p className="mt-4 text-lg font-medium">Brak danych</p>
              <p className="text-sm text-muted-foreground">Zacznij rejestrować swoje godziny, aby zobaczyć postępy.</p>
            </div>
          )}
        </CardContent>
      </Card>
      {userId && <WorkHistoryTable entries={entries || []} userId={userId} />}
    </div>
  );
}
