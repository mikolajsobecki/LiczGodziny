'use client';

import { useRef, useState, useTransition } from 'react';
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { z } from 'zod';

import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useFirestore, addDocumentNonBlocking, useDoc, useMemoFirebase } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import type { WorkDay, UserProfile } from '@/lib/types';
import { Skeleton } from './ui/skeleton';

interface TimeEntryFormProps {
  userId: string | null;
}

const FormSchema = z.object({
  date: z.date({ required_error: 'Data jest wymagana.' }),
  hours: z.coerce.number().min(0, 'Godziny nie mogą być ujemne.'),
});

type FormState = {
  errors: {
    date?: string[];
    hours?: string[];
  } | null;
};

export function TimeEntryForm({ userId }: TimeEntryFormProps) {
  const firestore = useFirestore();
  const { toast } = useToast();
  const formRef = useRef<HTMLFormElement>(null);

  const [date, setDate] = useState<Date | undefined>(new Date());
  const [isPending, startTransition] = useTransition();
  const [formState, setFormState] = useState<FormState>({ errors: null });

  const userDocRef = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return doc(firestore, 'users', userId);
  }, [firestore, userId]);
  const { data: userProfile, isLoading: isProfileLoading } = useDoc<UserProfile>(userDocRef);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!userId || !userProfile) return; // Guard against submission when user or profile is not loaded
    const formData = new FormData(event.currentTarget);

    startTransition(() => {
      const validatedFields = FormSchema.safeParse({
        date: date,
        hours: formData.get('hours'),
      });

      if (!validatedFields.success) {
        setFormState({ errors: validatedFields.error.flatten().fieldErrors });
        toast({
          variant: 'destructive',
          title: 'Nieprawidłowe dane',
          description: 'Sprawdź formularz i spróbuj ponownie.',
        });
        return;
      }

      const { date: validatedDate, hours } = validatedFields.data;

      const isSaturday = validatedDate.getDay() === 6; // 0 for Sunday, 6 for Saturday
      const regularRate = userProfile.regularRate;
      const overtimeRate = userProfile.overtimeRate;
      let earnings: number = 0;
      let avgRate: number = 0;
      let overtimeHours: number = 0;

      if (hours > 0) {
        if (isSaturday) {
          overtimeHours = hours;
          earnings = hours * overtimeRate;
          avgRate = overtimeRate;
        } else {
          if (hours <= 8) {
            overtimeHours = 0;
            earnings = hours * regularRate;
            avgRate = regularRate;
          } else {
            const regularHours = 8;
            overtimeHours = hours - regularHours;
            earnings = (regularHours * regularRate) + (overtimeHours * overtimeRate);
            avgRate = earnings / hours;
          }
        }
      }
      
      const workDay: Omit<WorkDay, 'id'> = {
        userId,
        date: validatedDate.toISOString(),
        hoursWorked: hours,
        hourlyRate: parseFloat(avgRate.toFixed(2)),
        earnings: parseFloat(earnings.toFixed(2)),
        overtimeHours: parseFloat(overtimeHours.toFixed(2)),
      };
      
      if (!firestore) return;
      const collectionRef = collection(firestore, 'users', userId, 'workDays');
      addDocumentNonBlocking(collectionRef, workDay);

      toast({
        title: 'Sukces!',
        description: 'Wpis czasu pracy został dodany pomyślnie!',
      });
      
      formRef.current?.reset();
      setDate(new Date());
      setFormState({ errors: null });
    });
  };
  
  if (!userId || isProfileLoading) {
    return (
        <Card>
            <CardHeader>
                <Skeleton className="h-8 w-3/4" />
                <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-2">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-10 w-full" />
                </div>
                <div className="space-y-2">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-10 w-full" />
                </div>
                <Skeleton className="h-10 w-full" />
            </CardContent>
        </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Zarejestruj swoje godziny</CardTitle>
        <CardDescription>Wprowadź szczegóły swojej pracy dla określonego dnia.</CardDescription>
      </CardHeader>
      <CardContent>
        <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="date">Data</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={'outline'}
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !date && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP', { weekStartsOn: 1}) : <span>Wybierz datę</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            {formState.errors?.date && <p className="text-sm font-medium text-destructive">{formState.errors.date[0]}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="hours">Przepracowane godziny</Label>
            <Input id="hours" name="hours" type="number" step="0.1" placeholder="np. 11" required defaultValue="11" />
            {formState.errors?.hours && <p className="text-sm font-medium text-destructive">{formState.errors.hours[0]}</p>}
          </div>
          
          <Button type="submit" className="w-full" disabled={isPending || !userId || !userProfile}>
            {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {isPending ? 'Zapisywanie...' : 'Dodaj wpis'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
