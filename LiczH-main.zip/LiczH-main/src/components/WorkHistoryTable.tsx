'use client';

import { useState } from 'react';
import { format } from 'date-fns';
import { Trash2, Edit, Loader2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import type { WorkDay, UserProfile } from '@/lib/types';
import { useFirestore, deleteDocumentNonBlocking, useDoc, useMemoFirebase } from '@/firebase';
import { collection, doc, writeBatch } from 'firebase/firestore';
import { EditWorkDayDialog } from './EditWorkDayDialog';
import { ExportPdfDialog } from './ExportPdfDialog';
import { useToast } from '@/hooks/use-toast';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

interface WorkHistoryTableProps {
  entries: WorkDay[];
  userId: string;
}

export function WorkHistoryTable({ entries, userId }: WorkHistoryTableProps) {
  const firestore = useFirestore();
  const { toast } = useToast();
  const [entryToEdit, setEntryToEdit] = useState<WorkDay | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const userDocRef = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return doc(firestore, 'users', userId);
  }, [firestore, userId]);

  const { data: userProfile } = useDoc<UserProfile>(userDocRef);

  const handleDelete = (workDayId: string) => {
    if (!firestore || !userId) return;
    const docRef = doc(firestore, 'users', userId, 'workDays', workDayId);
    deleteDocumentNonBlocking(docRef);
    toast({
      title: 'Usunięto!',
      description: 'Wpis został pomyślnie usunięty.',
    });
  };

  const handleClearAll = () => {
    if (!firestore || !userId || entries.length === 0) return;
    setIsDeleting(true);

    const workDaysRef = collection(firestore, 'users', userId, 'workDays');
    const batch = writeBatch(firestore);
    entries.forEach((entry) => {
      const docRef = doc(workDaysRef, entry.id);
      batch.delete(docRef);
    });

    batch.commit()
      .then(() => {
        toast({
          title: 'Wyczyszczono!',
          description: 'Wszystkie wpisy zostały usunięte.',
        });
      })
      .catch((error) => {
        const permissionError = new FirestorePermissionError({
          path: `users/${userId}/workDays`,
          operation: 'delete',
        });
        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setIsDeleting(false);
      });
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex-grow">
                <CardTitle>Szczegółowa historia</CardTitle>
                <CardDescription>Przeglądaj, edytuj lub usuwaj swoje wpisy.</CardDescription>
            </div>
            <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                {entries.length > 0 && <ExportPdfDialog entries={entries} userName={userProfile?.name} />}
                {entries.length > 0 && (
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive" disabled={isDeleting} className="w-full sm:w-auto">
                                {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                            <AlertDialogTitle>Czy na pewno chcesz usunąć wszystko?</AlertDialogTitle>
                            <AlertDialogDescription>
                                Ta akcja jest nieodwracalna. Wszystkie Twoje zapisane dni pracy zostaną trwale usunięte.
                            </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                            <AlertDialogCancel>Anuluj</AlertDialogCancel>
                            <AlertDialogAction onClick={handleClearAll} className="bg-destructive hover:bg-destructive/90">
                                {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                Usuń wszystko
                            </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                )}
            </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead className="text-right">Godziny</TableHead>
                <TableHead className="text-right">Nadgodziny</TableHead>
                <TableHead className="text-right">Śr. stawka</TableHead>
                <TableHead className="text-right">Zarobki</TableHead>
                <TableHead className="text-center">Akcje</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {entries.length > 0 ? (
                entries.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell>{format(new Date(entry.date), 'dd/MM/yyyy')}</TableCell>
                    <TableCell className="text-right">{entry.hoursWorked.toFixed(1)}</TableCell>
                    <TableCell className="text-right">{(entry.overtimeHours || 0).toFixed(1)}</TableCell>
                    <TableCell className="text-right">{entry.hourlyRate.toFixed(2)} zl</TableCell>
                    <TableCell className="text-right">{entry.earnings.toFixed(2)} zl</TableCell>
                    <TableCell className="flex justify-center gap-2">
                       <Button variant="ghost" size="icon" onClick={() => setEntryToEdit(entry)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                       <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                <AlertDialogTitle>Czy na pewno?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    Ta akcja jest nieodwracalna. Spowoduje to trwałe usunięcie wpisu.
                                </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                <AlertDialogCancel>Anuluj</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(entry.id)} className="bg-destructive hover:bg-destructive/90">
                                    Usuń
                                </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    Brak wpisów.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      {entryToEdit && (
         <EditWorkDayDialog
            isOpen={!!entryToEdit}
            onClose={() => setEntryToEdit(null)}
            workDay={entryToEdit}
            userId={userId}
        />
      )}
    </>
  );
}
