'use client';

import { useState } from 'react';
import { format } from 'date-fns';
import { pl } from 'date-fns/locale';
import { FileDown, Loader2 } from 'lucide-react';
import jsPDF from 'jspdf';
// jspdf-autotable is imported dynamically in generatePDF to avoid bundling issues in production
import { robotoRegularBase64, robotoBoldBase64 } from '@/lib/pdfFonts';

import type { WorkDay } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface ExportPdfDialogProps {
  entries: WorkDay[];
  userName?: string | null;
}

export function ExportPdfDialog({ entries, userName }: ExportPdfDialogProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const generatePDF = async () => {
    console.log('generatePDF called');
    toast({ title: 'Inicjowanie eksportu PDF...' });

    if (entries.length === 0) {
      console.log('generatePDF aborted: brak entries');
      return;
    }

    setIsGenerating(true);
    try {
      // load plugin dynamically; gets autoTable function directly
      const { default: autoTable } = await import('jspdf-autotable');
      const pdf = new jsPDF();

      // embed unicode fonts for Polish characters
      pdf.addFileToVFS('Roboto-Regular.ttf', robotoRegularBase64);
      // use Identity-H to support full unicode characters like ł, zł
      pdf.addFont('Roboto-Regular.ttf', 'Roboto', 'normal', 'Identity-H');
      pdf.addFileToVFS('Roboto-Bold.ttf', robotoBoldBase64);
      pdf.addFont('Roboto-Bold.ttf', 'Roboto', 'bold', 'Identity-H');
      pdf.setFont('Roboto', 'normal');

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      // Nagłówek
      pdf.setFont('Roboto','bold');
      pdf.setFontSize(20);
      pdf.text('Historia pracy', 20, 20);

      pdf.setFont('Roboto','normal');
      pdf.setFontSize(10);
      const generatedDate = format(new Date(), 'dd.MM.yyyy HH:mm', { locale: pl });
      pdf.text(`Wygenerowano: ${generatedDate}`, 20, 30);
      
      if (userName) {
        pdf.text(`Pracownik: ${userName}`, 20, 37);
      }

      // Przygotowanie danych do tabeli
      const tableData = entries.map((entry) => [
        format(new Date(entry.date), 'dd.MM.yyyy', { locale: pl }),
        entry.hoursWorked.toFixed(2),
        entry.overtimeHours ? entry.overtimeHours.toFixed(2) : '0',
        // omit hourly rate column
        `${entry.earnings.toFixed(2)} zl`,
      ]);

      // Obliczenia podsumowania
      const totalHours = entries.reduce((sum, e) => sum + e.hoursWorked, 0);
      const totalOvertimeHours = entries.reduce((sum, e) => sum + (e.overtimeHours || 0), 0);
      const totalEarnings = entries.reduce((sum, e) => sum + e.earnings, 0);

      // Tabela using explicit autoTable function
      autoTable(pdf, {
        head: [['Data', 'Godziny', 'Nadgodziny', 'Zarobki']],
        body: tableData,
        startY: userName ? 45 : 38,
        margin: { left: 20, right: 20 },
        headStyles: {
          fillColor: [59, 130, 246],
          textColor: [255, 255, 255],
          fontStyle: 'bold',
          halign: 'center',
        },
        bodyStyles: {
          textColor: [0, 0, 0],
          halign: 'center',
        },
        footStyles: {
          fillColor: [229, 231, 235],
          textColor: [0, 0, 0],
          fontStyle: 'bold',
          halign: 'center',
        },
        foot: [
          [
            'RAZEM:',
            totalHours.toFixed(2),
            totalOvertimeHours.toFixed(2),
            `${totalEarnings.toFixed(2)} zl`,
          ],
        ],
        alternateRowStyles: {
          fillColor: [245, 247, 250],
        },
      });

      // Podsumowanie poniżej tabeli
      const finalY = (pdf as any).lastAutoTable.finalY + 15;
      pdf.setFontSize(12);
      pdf.setFont('Roboto', 'bold');
      pdf.text('Podsumowanie:', 20, finalY);

      pdf.setFontSize(11);
      pdf.setFont('Roboto', 'bold');
      pdf.text(
        `Calkowite godziny pracy: ${totalHours.toFixed(2)} h`,
        20,
        finalY + 10
      );
      pdf.text(
        `Nadgodziny: ${totalOvertimeHours.toFixed(2)} h`,
        20,
        finalY + 18
      );
      pdf.text(
        `Calkowite zarobki: ${totalEarnings.toFixed(2)} zl`,
        20,
        finalY + 26
      );

      // Pobieranie pliku
      const fileName = `Historia_pracy_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.pdf`;
      pdf.save(fileName);
      console.log('PDF saved as', fileName);
      toast({ title: 'Pobrano PDF', description: fileName });
    } catch (error) {
      console.error('Błąd przy generowaniu PDF:', error);
      toast({
        title: 'Błąd przy generowaniu PDF',
        description: String(error),
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="outline" disabled={entries.length === 0} className="w-full sm:w-auto">
          <FileDown className="h-4 w-4" />
          Eksportuj PDF
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Potwierdzenie eksportu</AlertDialogTitle>
          <AlertDialogDescription>
            Czy na pewno chcesz pobrać historię pracy jako plik PDF? Zawiera {entries.length}{' '}
            {entries.length === 1 ? 'wpis' : entries.length < 5 ? 'wpisy' : 'wpisów'}.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Anuluj</AlertDialogCancel>
          <AlertDialogAction onClick={generatePDF} disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generowanie...
              </>
            ) : (
              'Pobierz PDF'
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
