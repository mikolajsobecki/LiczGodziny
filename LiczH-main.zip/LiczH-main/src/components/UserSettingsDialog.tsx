'use client';

import { useState, useEffect, useTransition } from 'react';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import type { UserProfile } from '@/lib/types';
import { useFirestore, updateDocumentNonBlocking } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

interface UserSettingsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile & { id: string };
}

const SettingsSchema = z.object({
  regularRate: z.coerce.number().min(0, 'Stawka nie może być ujemna.'),
  overtimeRate: z.coerce.number().min(0, 'Stawka nie może być ujemna.'),
  reminderTime: z.string().regex(/^\d{2}:\d{2}$/, 'Format: HH:MM').optional().or(z.literal('')),
  reminderEnabled: z.boolean().optional(),
});

export function UserSettingsDialog({ isOpen, onClose, userProfile }: UserSettingsDialogProps) {
  const firestore = useFirestore();
  const { toast } = useToast();
  const [regularRate, setRegularRate] = useState((userProfile.regularRate ?? 0).toString());
  const [overtimeRate, setOvertimeRate] = useState((userProfile.overtimeRate ?? 0).toString());
  const [reminderTime, setReminderTime] = useState((userProfile.reminderTime ?? '').toString());
  const [reminderEnabled, setReminderEnabled] = useState(userProfile.reminderEnabled ?? false);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    if (userProfile.regularRate !== undefined) {
      setRegularRate(userProfile.regularRate.toString());
    }
    if (userProfile.overtimeRate !== undefined) {
      setOvertimeRate(userProfile.overtimeRate.toString());
    }
    if (userProfile.reminderTime !== undefined) {
      setReminderTime(userProfile.reminderTime?.toString() ?? '');
    }
    if (userProfile.reminderEnabled !== undefined) {
      setReminderEnabled(userProfile.reminderEnabled);
    }
  }, [userProfile]);

  const handleSave = () => {
    startTransition(() => {
      const validatedFields = SettingsSchema.safeParse({ 
        regularRate, 
        overtimeRate,
        reminderTime: reminderTime || undefined,
        reminderEnabled,
      });

      if (!validatedFields.success) {
        const errors = validatedFields.error.flatten().fieldErrors;
        toast({
          variant: 'destructive',
          title: 'Nieprawidłowe dane',
          description: errors.regularRate?.[0] || errors.overtimeRate?.[0] || errors.reminderTime?.[0] || 'Sprawdź formularz.',
        });
        return;
      }

      const { regularRate: newRegularRate, overtimeRate: newOvertimeRate, reminderTime: newReminderTime, reminderEnabled: newReminderEnabled } = validatedFields.data;
      
      const updatedProfile: Partial<UserProfile> = {
        regularRate: newRegularRate,
        overtimeRate: newOvertimeRate,
        reminderTime: newReminderTime || null,
        reminderEnabled: newReminderEnabled,
      };
      
      if (!firestore) return;
      const docRef = doc(firestore, 'users', userProfile.id);
      updateDocumentNonBlocking(docRef, updatedProfile);

      toast({
        title: 'Zapisano!',
        description: 'Twoje ustawienia zostały zaktualizowane.',
      });
      onClose();
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Ustawienia stawek godzinowych</DialogTitle>
          <DialogDescription>
            Zmień swoje stawki, aby poprawnie obliczać zarobki.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="regular-rate">Stawka podstawowa (zł/h)</Label>
            <Input
              id="regular-rate"
              value={regularRate}
              onChange={(e) => setRegularRate(e.target.value)}
              type="number"
              step="0.01"
              placeholder="np. 27"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="overtime-rate">Stawka za nadgodziny (zł/h)</Label>
            <Input
              id="overtime-rate"
              value={overtimeRate}
              onChange={(e) => setOvertimeRate(e.target.value)}
              type="number"
              step="0.01"
              placeholder="np. 40"
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="reminder-enabled"
                checked={reminderEnabled}
                onCheckedChange={(checked) => setReminderEnabled(checked as boolean)}
              />
              <Label htmlFor="reminder-enabled" className="font-normal cursor-pointer">
                Włącz przypomnienia o dodaniu godzin
              </Label>
            </div>
          </div>
          {reminderEnabled && (
            <div className="space-y-2">
              <Label htmlFor="reminder-time">O jakiej godzinie przypominać? (HH:MM)</Label>
              <Input
                id="reminder-time"
                value={reminderTime}
                onChange={(e) => setReminderTime(e.target.value)}
                type="time"
                placeholder="18:30"
              />
            </div>
          )}
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Anuluj</Button>
          </DialogClose>
          <Button onClick={handleSave} disabled={isPending}>
            {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Zapisz zmiany
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
