'use client';

import { useState, useEffect, useTransition } from 'react';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import type { WorkDay, UserProfile } from '@/lib/types';
import { useFirestore, updateDocumentNonBlocking, useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

interface EditWorkDayDialogProps {
  isOpen: boolean;
  onClose: () => void;
  workDay: WorkDay;
  userId: string;
}

const EditSchema = z.object({
  hours: z.coerce.number().min(0, 'Godziny nie mogą być ujemne.'),
});

export function EditWorkDayDialog({ isOpen, onClose, workDay, userId }: EditWorkDayDialogProps) {
  const firestore = useFirestore();
  const { toast } = useToast();
  const [hours, setHours] = useState(workDay.hoursWorked.toString());
  const [isPending, startTransition] = useTransition();

  const userDocRef = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return doc(firestore, 'users', userId);
  }, [firestore, userId]);
  const { data: userProfile, isLoading: isProfileLoading } = useDoc<UserProfile>(userDocRef);

  useEffect(() => {
    setHours(workDay.hoursWorked.toString());
  }, [workDay]);

  const handleSave = () => {
    startTransition(() => {
      const validatedFields = EditSchema.safeParse({ hours });

      if (!validatedFields.success) {
        toast({
          variant: 'destructive',
          title: 'Nieprawidłowe dane',
          description: validatedFields.error.flatten().fieldErrors.hours?.[0] || 'Sprawdź formularz.',
        });
        return;
      }

      const newHours = validatedFields.data.hours;
      
      const workDate = new Date(workDay.date);
      const isSaturday = workDate.getDay() === 6;
      const regularRate = userProfile?.regularRate ?? 30;
      const overtimeRate = userProfile?.overtimeRate ?? 43;
      let earnings: number = 0;
      let avgRate: number = 0;
      let overtimeHours: number = 0;

      if (newHours > 0) {
        if (isSaturday) {
          overtimeHours = newHours;
          earnings = newHours * overtimeRate;
          avgRate = overtimeRate;
        } else {
          if (newHours <= 8) {
            overtimeHours = 0;
            earnings = newHours * regularRate;
            avgRate = regularRate;
          } else {
            const regularHours = 8;
            overtimeHours = newHours - regularHours;
            earnings = (regularHours * regularRate) + (overtimeHours * overtimeRate);
            avgRate = earnings / newHours;
          }
        }
      }
      
      const updatedWorkDay: Partial<WorkDay> = {
        hoursWorked: newHours,
        hourlyRate: parseFloat(avgRate.toFixed(2)),
        earnings: parseFloat(earnings.toFixed(2)),
        overtimeHours: parseFloat(overtimeHours.toFixed(2)),
      };
      
      if (!firestore) return;
      const docRef = doc(firestore, 'users', userId, 'workDays', workDay.id);
      updateDocumentNonBlocking(docRef, updatedWorkDay);

      toast({
        title: 'Zapisano!',
        description: 'Wpis został zaktualizowany.',
      });
      onClose();
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edytuj dzień pracy</DialogTitle>
          <DialogDescription>
            Zaktualizuj liczbę przepracowanych godzin dla {new Date(workDay.date).toLocaleDateString('pl-PL')}.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="edit-hours">Przepracowane godziny</Label>
            <Input
              id="edit-hours"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              type="number"
              step="0.1"
              placeholder="np. 8"
            />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Anuluj</Button>
          </DialogClose>
          <Button onClick={handleSave} disabled={isPending || isProfileLoading}>
            {isPending || isProfileLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Zapisz zmiany
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
