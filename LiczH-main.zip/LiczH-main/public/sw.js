const CACHE_NAME = 'liczgodziny-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/manifest.json',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];

// Instalacja: Zapisujemy wszystko do cache
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
});

// Aktywacja: Przejmujemy kontrolę nad wszystkimi kartami
self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", function(event) {

  const data = event.data.json();

  self.registration.showNotification(data.title, {
    body: data.body,
    icon: "/icon-192.png"
  });

});



// Obsługa żądań: Najpierw sieć, jeśli błąd - podajemy z cache
self.addEventListener('fetch', (event) => {
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, copy);
          });
          return response;
        })
        .catch(() => {
          return caches.match('/') || caches.match(event.request);
        })
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});

// Obsługa zdarzenia push z FCM lub innego serwisu push.
self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    console.warn('push event data was not JSON', e);
  }

  const title = data.notification?.title || 'LiczGodziny';
  const options = {
    body: data.notification?.body || '',
    icon: '/manifest.json',
    tag: data.notification?.tag || 'work-reminder',
  };

  event.waitUntil(self.registration.showNotification(title, options));
});
