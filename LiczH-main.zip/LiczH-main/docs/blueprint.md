# **App Name**: TimeTrack Pro

## Core Features:

- Daily Hour Input: Allow the user to input the number of hours worked for a specific day.
- Realtime Database Storage: Store the daily hours and calculated sum in a Firestore database.
- Sum Calculation: Automatically calculate the sum of hours worked across all days.
- Monetary Sum Calculation: Add field for salary to daily number and auto calculates sum to salary worked
- Visual Summary: Provide a graph of all numbers with dates on the x axis.

## Style Guidelines:

- Primary color: Light grayish-blue (#98AFC7) to convey calmness and productivity.
- Background color: Very light grayish-blue (#E6EBF0) to provide a clean, non-distracting backdrop.
- Accent color: Soft lavender (#C8A2C8) for interactive elements, providing a gentle contrast.
- Body and headline font: 'Inter' for a clean, modern and readable appearance.
- Use simple, consistent icons for navigation and actions related to time and money.
- Design a clear, intuitive layout that simplifies data entry and overview, optimized for mobile devices.
- Use subtle transitions and animations for feedback, such as saving hours or updating the sum.