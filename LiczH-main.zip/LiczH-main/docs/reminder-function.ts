import * as functions from 'firebase-functions';
import admin from 'firebase-admin';

// initialise admin if not already
if (!admin.apps.length) {
  admin.initializeApp();
}

// helper to convert HH:MM to minutes since midnight
function toMinutes(hhmm: string) {
  const [hh, mm] = hhmm.split(':').map((s) => parseInt(s, 10));
  return hh * 60 + mm;
}

// Run every 5 minutes (for example) and send a notification to any user whose
// reminderTime matches the current hour & minute.  In production you can use
// pubsub.schedule('every 1 minutes') instead.
export const sendDailyReminders = functions.pubsub
  .schedule('every 5 minutes')
  .onRun(async (context) => {
    const now = new Date();
    const current = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

    const snapshot = await admin
      .firestore()
      .collection('users')
      .where('reminderEnabled', '==', true)
      .where('reminderTime', '==', current)
      .get();

    const tokens: string[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      if (data.fcmToken) {
        tokens.push(data.fcmToken);
      }
    });

    if (tokens.length === 0) {
      return null;
    }

    // send a multicast message
    const message: admin.messaging.MulticastMessage = {
      notification: {
        title: 'Przypomnienie LiczH',
        body: 'Nie zapomnij o dodaniu dzisiejszych godzin! ⏰',
        tag: 'work-reminder',
      },
      tokens,
    };

    const response = await admin.messaging().sendMulticast(message);
    console.log(`sent ${response.successCount}/${tokens.length} reminders`);
    return null;
  });
